<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => 'Profil & Proses']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Profil & Proses']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php $wa = $profile->whatsappLink(); ?>

    <section class="max-w-container-max mx-auto px-gutter pt-12 md:pt-16 pb-12">
        <p class="eyebrow reveal-on-scroll">Profil usaha</p>
        <h1 class="reveal-on-scroll font-display text-5xl md:text-7xl mt-3 leading-[1] tracking-tight"><?php echo e($profile->business_name); ?></h1>

        <div class="mt-12 grid lg:grid-cols-12 gap-10">
            <div class="lg:col-span-7 reveal-on-scroll">
                <dl class="border-t border-ink grid sm:grid-cols-2">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = array_filter([
                        ['Pemilik dan perajin', $profile->owner_name],
                        ['Berdiri', $profile->since_year],
                        ['Bengkel', $profile->address],
                        ['Sistem pemesanan', 'Dibuat sesuai pesanan, dikonfirmasi lewat WhatsApp'],
                    ], fn ($r) => filled($r[1])); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$k, $v]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <div class="py-4 border-b border-rule sm:pr-6">
                        <dt class="eyebrow"><?php echo e($k); ?></dt>
                        <dd class="mt-1.5 font-semibold text-ink leading-snug"><?php echo e($v); ?></dd>
                    </div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </dl>
                <div data-testid="profil-about" class="mt-8 space-y-4 text-ink-soft text-[1.05rem] leading-relaxed max-w-2xl">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = preg_split("/\n\s*\n/", trim((string) $profile->about)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $para): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($para)): ?><p><?php echo e($para); ?></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                </div>
            </div>
            <figure class="lg:col-span-5 reveal-on-scroll" data-delay="150">
                <div class="overflow-hidden rounded-[3px] bg-tint">
                    <img src="<?php echo e(asset('images/calung/papan-usaha.jpg')); ?>" alt="Papan usaha <?php echo e($profile->business_name); ?>" class="w-full h-auto object-cover"/>
                </div>
                <figcaption class="mt-2 font-mono text-[11px] text-muted">Papan usaha di bengkel <?php echo e($profile->business_name); ?>.</figcaption>
            </figure>
        </div>
    </section>

    <section id="proses" class="max-w-container-max mx-auto px-gutter py-12">
        <div class="grid md:grid-cols-12 gap-6 items-end reveal-on-scroll">
            <div class="md:col-span-7">
                <p class="eyebrow">Proses pembuatan</p>
                <h2 class="font-display text-4xl md:text-5xl mt-2 leading-tight">Bagaimana calung <em class="text-amber">dibuat</em></h2>
            </div>
            <p class="md:col-span-5 text-ink-soft">Setiap alat dikerjakan tangan, dari memilih bambu sampai menyetel nada.</p>
        </div>
        <ol data-testid="process-steps" class="mt-10 border-t border-ink">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <li class="reveal-on-scroll group grid md:grid-cols-12 gap-5 md:gap-8 py-8 border-b border-rule items-center">
                <span class="md:col-span-2 font-display text-6xl md:text-7xl leading-none text-amber/70 group-hover:text-amber transition-colors"><?php echo e(str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT)); ?></span>
                <div class="md:col-span-4 overflow-hidden rounded-[3px] aspect-[4/3] bg-tint">
                    <img src="<?php echo e($step->image_url); ?>" alt="<?php echo e($step->title); ?>" loading="lazy" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"/>
                </div>
                <div class="md:col-span-6">
                    <h3 class="font-display text-3xl leading-tight"><?php echo e($step->title); ?></h3>
                    <p class="mt-3 text-ink-soft leading-relaxed"><?php echo e($step->description); ?></p>
                </div>
            </li>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <li class="py-6 text-ink-soft">Tahapan proses belum diisi.</li>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </ol>
    </section>

    <section class="max-w-container-max mx-auto px-gutter py-10">
        <div class="border border-ink rounded-[3px] p-8 md:p-10 grid md:grid-cols-12 gap-6 items-center reveal-on-scroll">
            <div class="md:col-span-7">
                <h2 class="font-display text-3xl md:text-4xl leading-tight">Lihat alat yang bisa dipesan</h2>
                <p class="mt-2 text-ink-soft">Calung, angklung, pelengkap, dan kerajinan bambu.</p>
            </div>
            <div class="md:col-span-5 flex flex-wrap md:justify-end gap-3">
                <a href="<?php echo e(route('katalog')); ?>" class="btn btn-ink">Buka katalog <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'arrow','class' => 'w-4 h-4 arrow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow','class' => 'w-4 h-4 arrow']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?></a>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($wa): ?>
                <a href="<?php echo e($wa); ?>" target="_blank" rel="noopener" class="btn btn-line"><?php if (isset($component)) { $__componentOriginalca3539e0d920b2ba307b4e983da96e36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca3539e0d920b2ba307b4e983da96e36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.wa-icon','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wa-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $attributes = $__attributesOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $component = $__componentOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__componentOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?> WhatsApp</a>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\kuliah\mpi\kelompok baru\kode\mpi-katalog-calung\resources\views/profil.blade.php ENDPATH**/ ?>