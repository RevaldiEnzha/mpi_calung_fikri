<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['class' => 'w-9 h-9']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['class' => 'w-9 h-9']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<svg <?php echo e($attributes->merge(['class' => $class])); ?> viewBox="0 0 40 40" fill="none" aria-hidden="true">
    <circle cx="20" cy="20" r="19" stroke="currentColor" stroke-width="1.4"/>
    <g fill="currentColor">
        <rect x="9" y="10" width="2.6" height="20" rx="1"/>
        <rect x="12.9" y="11.5" width="2.6" height="17" rx="1"/>
        <rect x="16.8" y="13" width="2.6" height="14" rx="1"/>
        <rect x="20.7" y="14.5" width="2.6" height="11" rx="1"/>
        <rect x="24.6" y="16" width="2.6" height="8" rx="1"/>
        <rect x="28.5" y="17.5" width="2.6" height="5" rx="1"/>
    </g>
    <path d="M7 17.2 33 19.2M7 22.8 33 20.8" stroke="currentColor" stroke-width="1" opacity=".55"/>
</svg>
<?php /**PATH D:\kuliah\mpi\kelompok baru\kode\mpi-katalog-calung\resources\views/components/logo-mark.blade.php ENDPATH**/ ?>