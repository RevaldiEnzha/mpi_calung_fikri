<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product', 'delay' => 0, 'index' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product', 'delay' => 0, 'index' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<a href="<?php echo e(route('product-detail', $product->id)); ?>" data-testid="product-card" data-category="<?php echo e($product->category); ?>"
   class="product-item product-card group reveal-on-scroll flex flex-col" data-delay="<?php echo e($delay); ?>">
    <div class="thumb relative aspect-[4/3] overflow-hidden bg-tint rounded-[3px]">
        <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" loading="lazy" decoding="async" class="w-full h-full object-cover"/>
        <span class="absolute top-0 left-0 bg-paper/90 backdrop-blur px-2.5 py-1 font-mono text-[11px] tracking-wider text-ink">No. <?php echo e(str_pad((string) ($index ?? $product->sort_order ?: $product->id), 2, '0', STR_PAD_LEFT)); ?></span>
    </div>
    <div class="pt-4 pb-1 border-b border-rule flex-1 flex flex-col">
        <p class="eyebrow"><?php echo e($product->category ?: 'Produk'); ?></p>
        <h3 class="mt-1.5 font-display text-[1.7rem] leading-tight text-ink"><span class="title"><?php echo e($product->name); ?></span></h3>
        <p class="mt-2 text-sm text-ink-soft line-clamp-2 flex-1"><?php echo e($product->description); ?></p>
        <div class="mt-4 mb-3 flex items-end justify-between gap-3">
            <div>
                <span class="block font-semibold text-ink"><?php echo e($product->formatted_price); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->is_made_to_order): ?>
                <span data-testid="badge-pesanan" class="mt-1 inline-flex items-center gap-1.5 text-xs text-clay font-medium"><span class="w-1.5 h-1.5 rounded-full bg-clay"></span>Dibuat sesuai pesanan</span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
            <span class="w-9 h-9 shrink-0 border border-rule rounded-sm flex items-center justify-center text-ink-soft group-hover:bg-ink group-hover:text-paper group-hover:border-ink transition-colors">
                <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'arrow','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow','class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
            </span>
        </div>
    </div>
</a>
<?php /**PATH D:\kuliah\mpi\kelompok baru\kode\mpi-katalog-calung\resources\views/components/product-card.blade.php ENDPATH**/ ?>