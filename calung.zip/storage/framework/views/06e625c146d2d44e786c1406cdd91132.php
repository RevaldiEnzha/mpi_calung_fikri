<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['title' => null]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['title' => null]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<?php
    $siteName = $profile->business_name ?? 'Mandiri Laras Production';
    $waGeneral = $profile->whatsappLink();
    $navItems = [
        ['route' => 'home', 'match' => 'home', 'label' => 'Beranda', 'id' => 'home'],
        ['route' => 'profil', 'match' => 'profil', 'label' => 'Profil & Proses', 'id' => 'profil'],
        ['route' => 'katalog', 'match' => 'katalog*', 'label' => 'Katalog', 'id' => 'katalog'],
    ];
    // detail produk juga dianggap bagian katalog
    $isActive = fn ($item) => request()->routeIs($item['match']) || ($item['id'] === 'katalog' && request()->routeIs('product-detail'));
?>
<!DOCTYPE html>
<html lang="id" data-theme="light">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title><?php echo e($title ? $title . ' | ' . $siteName : $siteName . ' | Calung dan Angklung Bambu'); ?></title>
    <meta name="description" content="<?php echo e($profile->tagline ?? 'Calung dan angklung bambu wulung, dibuat sesuai pesanan.'); ?>"/>
    <meta name="turbo-cache-control" content="no-preview"/>
    <script>
        (function () {
            var t = null;
            try { t = localStorage.getItem('mlp-theme'); } catch (e) {}
            if (t !== 'light' && t !== 'dark') {
                t = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
            }
            document.documentElement.setAttribute('data-theme', t);
        })();
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com"/>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Manrope:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500&display=swap"/>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body class="min-h-screen flex flex-col text-ink font-body antialiased">

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($profile->is_demo): ?>
<div id="demo-banner" data-testid="demo-banner" class="demo-stripe text-center text-xs sm:text-[13px] font-semibold px-4 py-1.5">
    <span class="bg-[#F6EBD6] px-2 py-0.5 rounded-sm"><span class="sm:hidden">Versi demo, data masih data uji.</span><span class="hidden sm:inline">Versi demo internal. Data produk dan nomor WhatsApp masih data uji.</span></span>
</div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<nav id="main-nav" class="sticky top-0 z-50 bg-paper/85 backdrop-blur-md border-b border-rule transition-shadow duration-300">
    <div class="max-w-container-max mx-auto px-gutter h-[68px] flex items-center justify-between gap-6">
        <a id="nav-logo" data-testid="nav-logo" href="<?php echo e(route('home')); ?>" class="flex items-center gap-3 text-ink group">
            <?php if (isset($component)) { $__componentOriginal4383542ad8210ed40ff2e701a8552b53 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4383542ad8210ed40ff2e701a8552b53 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo-mark','data' => ['class' => 'w-10 h-10 text-amber transition-transform duration-500 group-hover:rotate-[-8deg]']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-10 h-10 text-amber transition-transform duration-500 group-hover:rotate-[-8deg]']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4383542ad8210ed40ff2e701a8552b53)): ?>
<?php $attributes = $__attributesOriginal4383542ad8210ed40ff2e701a8552b53; ?>
<?php unset($__attributesOriginal4383542ad8210ed40ff2e701a8552b53); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4383542ad8210ed40ff2e701a8552b53)): ?>
<?php $component = $__componentOriginal4383542ad8210ed40ff2e701a8552b53; ?>
<?php unset($__componentOriginal4383542ad8210ed40ff2e701a8552b53); ?>
<?php endif; ?>
            <span class="leading-none">
                <span class="block font-display text-[1.45rem] tracking-tight"><?php echo e(\Illuminate\Support\Str::of($siteName)->replace(' Production', '')); ?></span>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(\Illuminate\Support\Str::endsWith($siteName, 'Production')): ?>
                <span class="block font-mono text-[10px] tracking-[0.3em] text-muted mt-0.5">PRODUCTION</span>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </span>
        </a>

        <div class="hidden md:flex items-center gap-8">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a id="nav-<?php echo e($item['id']); ?>" data-testid="nav-<?php echo e($item['id']); ?>" href="<?php echo e(route($item['route'])); ?>" class="nav-link"
               <?php if($isActive($item)): ?> aria-current="page" <?php endif; ?>><span class="font-mono text-[10px] text-muted mr-1.5">0<?php echo e($n + 1); ?></span><?php echo e($item['label']); ?></a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>

        <div class="flex items-center gap-2">
            <button type="button" id="theme-toggle" data-testid="theme-toggle" class="w-10 h-10 rounded-sm border border-rule text-ink-soft hover:text-amber hover:border-amber transition-colors flex items-center justify-center" aria-label="Ganti tema terang atau gelap">
                <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'moon','class' => 'w-[18px] h-[18px] theme-icon-dark']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'moon','class' => 'w-[18px] h-[18px] theme-icon-dark']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'sun','class' => 'w-[18px] h-[18px] theme-icon-light']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'sun','class' => 'w-[18px] h-[18px] theme-icon-light']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
            </button>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($waGeneral): ?>
            <a id="nav-wa" data-testid="nav-wa" href="<?php echo e($waGeneral); ?>" target="_blank" rel="noopener" class="hidden md:inline-flex btn btn-line !py-2 !px-4 text-sm">
                <?php if (isset($component)) { $__componentOriginalca3539e0d920b2ba307b4e983da96e36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca3539e0d920b2ba307b4e983da96e36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.wa-icon','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wa-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $attributes = $__attributesOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $component = $__componentOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__componentOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?> Tanya pesanan
            </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <button type="button" id="mobile-menu-btn" data-testid="mobile-menu-btn" class="md:hidden w-10 h-10 rounded-sm border border-rule text-ink flex items-center justify-center" aria-label="Buka menu" aria-expanded="false" aria-controls="mobile-menu">
                <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'menu','class' => 'w-5 h-5 menu-icon-open']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'menu','class' => 'w-5 h-5 menu-icon-open']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
                <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'close','class' => 'w-5 h-5 menu-icon-close']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'close','class' => 'w-5 h-5 menu-icon-close']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
            </button>
        </div>
    </div>

    <div id="mobile-menu" data-testid="mobile-menu" class="md:hidden hidden border-t border-rule bg-paper">
        <div class="px-gutter py-3 flex flex-col">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $navItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
            <a data-testid="nav-<?php echo e($item['id']); ?>-mobile" href="<?php echo e(route($item['route'])); ?>" class="py-3.5 border-b border-rule flex items-baseline gap-3 <?php echo e($isActive($item) ? 'text-ink font-semibold' : 'text-ink-soft'); ?>">
                <span class="font-mono text-[11px] text-amber">0<?php echo e($n + 1); ?></span><span class="font-display text-2xl"><?php echo e($item['label']); ?></span>
            </a>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($waGeneral): ?>
            <a data-testid="nav-wa-mobile" href="<?php echo e($waGeneral); ?>" target="_blank" rel="noopener" class="btn btn-ink mt-4 mb-2">
                <?php if (isset($component)) { $__componentOriginalca3539e0d920b2ba307b4e983da96e36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca3539e0d920b2ba307b4e983da96e36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.wa-icon','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wa-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $attributes = $__attributesOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $component = $__componentOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__componentOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?> Tanya pesanan lewat WhatsApp
            </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</nav>

<div class="flex-1">
    <main id="konten">
    <?php echo e($slot); ?>

    </main>
</div>

<footer class="mt-20 border-t border-rule">
    <div class="max-w-container-max mx-auto px-gutter pt-14 pb-10 grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
            <div class="flex items-center gap-3 text-amber">
                <?php if (isset($component)) { $__componentOriginal4383542ad8210ed40ff2e701a8552b53 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4383542ad8210ed40ff2e701a8552b53 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.logo-mark','data' => ['class' => 'w-11 h-11']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('logo-mark'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-11 h-11']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4383542ad8210ed40ff2e701a8552b53)): ?>
<?php $attributes = $__attributesOriginal4383542ad8210ed40ff2e701a8552b53; ?>
<?php unset($__attributesOriginal4383542ad8210ed40ff2e701a8552b53); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4383542ad8210ed40ff2e701a8552b53)): ?>
<?php $component = $__componentOriginal4383542ad8210ed40ff2e701a8552b53; ?>
<?php unset($__componentOriginal4383542ad8210ed40ff2e701a8552b53); ?>
<?php endif; ?>
                <span class="font-display text-3xl text-ink"><?php echo e($siteName); ?></span>
            </div>
            <p class="mt-4 text-ink-soft max-w-sm leading-relaxed"><?php echo e($profile->tagline); ?></p>
            <div class="bilah mt-6" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>
        </div>
        <div>
            <p class="eyebrow mb-3">Bengkel</p>
            <p class="text-sm text-ink-soft leading-relaxed"><?php echo e($profile->address ?: 'Alamat belum diisi.'); ?></p>
        </div>
        <div>
            <p class="eyebrow mb-3">Hubungi</p>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($waGeneral): ?>
            <a data-testid="footer-wa" href="<?php echo e($waGeneral); ?>" target="_blank" rel="noopener" class="link-arrow text-sm">
                <?php if (isset($component)) { $__componentOriginalca3539e0d920b2ba307b4e983da96e36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca3539e0d920b2ba307b4e983da96e36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.wa-icon','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wa-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $attributes = $__attributesOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $component = $__componentOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__componentOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?> WhatsApp
            </a>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            <div class="flex gap-4 mt-4 text-sm">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = ['instagram' => 'Instagram', 'facebook' => 'Facebook', 'tiktok' => 'TikTok']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($profile->$field)): ?>
                    <a href="<?php echo e($profile->$field); ?>" target="_blank" rel="noopener" class="text-ink-soft hover:text-amber transition-colors"><?php echo e($label); ?></a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </div>
        </div>
    </div>
    <div class="border-t border-rule">
        <div class="max-w-container-max mx-auto px-gutter py-5 flex flex-col sm:flex-row justify-between gap-2 font-mono text-[11px] tracking-wide text-muted">
            <p>© <?php echo e(date('Y')); ?> <?php echo e($siteName); ?></p>
            <p>Website dikembangkan oleh Laras Digital Studio</p>
        </div>
    </div>
</footer>

<script>
    function mlpApplyTheme() {
        var t = null;
        try { t = localStorage.getItem('mlp-theme'); } catch (e) {}
        if (t === 'light' || t === 'dark') document.documentElement.setAttribute('data-theme', t);
    }

    function mlpInitReveal() {
        var els = document.querySelectorAll('.reveal-on-scroll:not(.is-revealed)');
        if (!('IntersectionObserver' in window)) { els.forEach(function (el) { el.classList.add('is-revealed'); }); return; }
        var obs = new IntersectionObserver(function (entries, o) {
            entries.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-revealed'); o.unobserve(e.target); } });
        }, { threshold: 0.08 });
        els.forEach(function (el) {
            var d = el.getAttribute('data-delay');
            if (d) el.style.transitionDelay = d + 'ms';
            obs.observe(el);
        });
    }

    if (!window.__mlpInit) {
        window.__mlpInit = true;

        document.addEventListener('click', function (e) {
            if (e.target.closest('#theme-toggle')) {
                var next = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
                document.documentElement.setAttribute('data-theme', next);
                try { localStorage.setItem('mlp-theme', next); } catch (err) {}
                mlpApplyTheme();
                return;
            }
            var btn = e.target.closest('#mobile-menu-btn');
            if (btn) {
                var menu = document.getElementById('mobile-menu');
                var open = menu.classList.toggle('hidden') === false;
                btn.setAttribute('aria-expanded', open ? 'true' : 'false');
                btn.setAttribute('aria-label', open ? 'Tutup menu' : 'Buka menu');
            }
        });

        window.addEventListener('scroll', function () {
            var nav = document.getElementById('main-nav');
            if (nav) nav.classList.toggle('shadow-[0_8px_24px_-18px_rgba(0,0,0,.45)]', window.scrollY > 20);
        }, { passive: true });

        var boot = function () { mlpApplyTheme(); mlpInitReveal(); };
        document.addEventListener('turbo:load', boot);
        document.addEventListener('DOMContentLoaded', function () { if (!window.Turbo) boot(); });
    }
</script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH D:\kuliah\mpi\kelompok baru\kode\mpi-katalog-calung\resources\views/components/layout.blade.php ENDPATH**/ ?>