<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => ['title' => $product->name]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product->name)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php
        $wa = $profile->whatsappLink($product->name);
        $no = str_pad((string) ($product->sort_order ?: $product->id), 2, '0', STR_PAD_LEFT);
    ?>

    <section class="max-w-container-max mx-auto px-gutter pt-8 pb-12">
        <nav class="flex items-center gap-1.5 font-mono text-[11px] tracking-wide uppercase text-muted mb-8" aria-label="Breadcrumb">
            <a href="<?php echo e(route('katalog')); ?>" class="hover:text-amber transition-colors">Katalog</a>
            <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'chevron','class' => 'w-3.5 h-3.5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'chevron','class' => 'w-3.5 h-3.5']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
            <span class="text-ink"><?php echo e($product->name); ?></span>
        </nav>

        <div class="grid lg:grid-cols-12 gap-10 lg:gap-14 items-start">
            <div class="lg:col-span-7 reveal-on-scroll">
                <div class="relative overflow-hidden rounded-[3px] bg-tint aspect-[4/3]">
                    <img data-testid="detail-image" src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-full object-cover"/>
                    <span class="absolute top-0 left-0 bg-paper/90 backdrop-blur px-3 py-1.5 font-mono text-xs tracking-wider">No. <?php echo e($no); ?></span>
                </div>
            </div>

            <div class="lg:col-span-5 reveal-on-scroll" data-delay="120">
                <p class="eyebrow"><?php echo e($product->category ?: 'Produk'); ?></p>
                <h1 data-testid="detail-name" class="font-display text-5xl md:text-6xl mt-2 leading-[1.02] tracking-tight"><?php echo e($product->name); ?></h1>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($product->is_made_to_order): ?>
                <p data-testid="detail-badge-pesanan" class="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-clay"><span class="w-2 h-2 rounded-full bg-clay"></span>Dibuat sesuai pesanan</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <p class="mt-4 text-lg text-ink-soft leading-relaxed"><?php echo e($product->description); ?></p>

                <dl class="mt-7 border-t border-ink">
                    <div class="py-4 border-b border-rule flex justify-between items-baseline gap-4">
                        <dt class="eyebrow">Harga</dt>
                        <dd data-testid="detail-price" class="font-display text-3xl text-ink"><?php echo e($product->formatted_price); ?></dd>
                    </div>
                    <div class="py-4 border-b border-rule flex justify-between items-baseline gap-4">
                        <dt class="eyebrow">Perkiraan pengerjaan</dt>
                        <dd data-testid="detail-lead-time" class="font-semibold text-right"><?php echo e($product->lead_time ?: 'Dikonfirmasi saat pemesanan'); ?></dd>
                    </div>
                </dl>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(filled($product->content)): ?>
                <div class="prose-calung mt-6 text-ink-soft"><?php echo $product->content; ?></div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <div class="mt-8">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($wa): ?>
                    <a href="<?php echo e($wa); ?>" target="_blank" rel="noopener" data-testid="wa-button" class="btn btn-ink w-full !py-4 text-base">
                        <?php if (isset($component)) { $__componentOriginalca3539e0d920b2ba307b4e983da96e36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca3539e0d920b2ba307b4e983da96e36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.wa-icon','data' => ['class' => 'w-5 h-5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wa-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-5 h-5']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $attributes = $__attributesOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $component = $__componentOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__componentOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?> Pesan lewat WhatsApp <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'arrow','class' => 'w-4 h-4 arrow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow','class' => 'w-4 h-4 arrow']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
                    </a>
                    <?php else: ?>
                    <p data-testid="wa-missing" class="text-ink-soft">Nomor WhatsApp belum diatur oleh admin.</p>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    <p class="mt-3 text-xs text-muted leading-relaxed">Tombol ini membuka WhatsApp dengan pesan berisi nama produk. Percakapan berlangsung di WhatsApp, website tidak menyimpan isi chat.</p>
                </div>
            </div>
        </div>
    </section>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($related->isNotEmpty()): ?>
    <section class="max-w-container-max mx-auto px-gutter py-10">
        <div class="flex items-end justify-between gap-4 mb-8 border-t border-ink pt-6">
            <h2 class="font-display text-3xl md:text-4xl">Produk lain</h2>
            <a href="<?php echo e(route('katalog')); ?>" class="link-arrow text-ink text-sm">Semua produk <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'arrow','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow','class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?></a>
        </div>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $item,'delay' => ($i + 1) * 90]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item),'delay' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($i + 1) * 90)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </div>
    </section>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\kuliah\mpi\kelompok baru\kode\mpi-katalog-calung\resources\views/product-detail.blade.php ENDPATH**/ ?>