<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

    <?php
        $wa = $profile->whatsappLink();
        $kota = $profile->address ? \Illuminate\Support\Str::before($profile->address, ', Jawa') : 'Banyumas';
        $stepHeights = ['lg:h-[360px]', 'lg:h-[325px]', 'lg:h-[290px]', 'lg:h-[255px]', 'lg:h-[220px]'];
    ?>

    
    <section class="max-w-container-max mx-auto px-gutter pt-12 md:pt-20 pb-16">
        <p class="eyebrow reveal-on-scroll">Perajin alat musik bambu<?php echo e($profile->since_year ? ' sejak ' . $profile->since_year : ''); ?> &middot; Banyumas</p>
        <h1 class="reveal-on-scroll font-display text-[2.9rem] sm:text-6xl lg:text-[5.4rem] leading-[0.98] tracking-tight mt-5 max-w-5xl text-ink">
            Calung bambu wulung, <em class="text-amber">dibuat sesuai pesanan.</em>
        </h1>

        <div class="mt-12 grid lg:grid-cols-12 gap-10 lg:gap-8 items-end">
            <div class="lg:col-span-4 reveal-on-scroll" data-delay="80">
                <p class="text-lg text-ink-soft leading-relaxed">
                    <?php echo e($profile->business_name); ?> membuat calung Banyumasan, angklung, dan kerajinan bambu di <?php echo e($kota); ?>. Pilih alatnya di katalog, lalu tanyakan pesananmu lewat WhatsApp.
                </p>
                <div class="mt-7 flex flex-wrap gap-3">
                    <a href="<?php echo e(route('katalog')); ?>" data-testid="hero-katalog" class="btn btn-ink">Lihat katalog <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'arrow','class' => 'w-4 h-4 arrow']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow','class' => 'w-4 h-4 arrow']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?></a>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($wa): ?>
                    <a href="<?php echo e($wa); ?>" target="_blank" rel="noopener" data-testid="hero-wa" class="btn btn-line"><?php if (isset($component)) { $__componentOriginalca3539e0d920b2ba307b4e983da96e36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca3539e0d920b2ba307b4e983da96e36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.wa-icon','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wa-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $attributes = $__attributesOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $component = $__componentOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__componentOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?> Tanya dulu</a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <figure class="lg:col-span-5 reveal-on-scroll" data-delay="160">
                <div class="relative overflow-hidden rounded-[3px] aspect-[4/3] bg-tint group">
                    <img src="<?php echo e($profile->cover_image_url); ?>" alt="Calung buatan <?php echo e($profile->business_name); ?>" fetchpriority="high" class="w-full h-full object-cover transition-transform duration-[1.2s] group-hover:scale-[1.04]"/>
                </div>
                <figcaption class="mt-2 font-mono text-[11px] text-muted">Calung Banyumasan dari bengkel di Desa Kemutug Lor.</figcaption>
            </figure>

            <dl class="lg:col-span-3 reveal-on-scroll border-t border-ink" data-delay="240">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = [['Bahan', 'Bambu wulung pilihan'], ['Nada', 'Disetel dengan tuner'], ['Pemesanan', 'Satu per satu, sesuai kebutuhan'], ['Pengiriman', 'Sampai luar Jawa']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$k, $v]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <div class="py-3.5 border-b border-rule flex justify-between gap-4">
                    <dt class="eyebrow pt-0.5"><?php echo e($k); ?></dt>
                    <dd class="text-sm font-semibold text-right text-ink"><?php echo e($v); ?></dd>
                </div>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <div class="bilah mt-6" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>
            </dl>
        </div>
    </section>

    
    <section class="max-w-container-max mx-auto px-gutter py-14" id="unggulan">
        <div class="grid md:grid-cols-12 gap-6 items-end mb-10 reveal-on-scroll">
            <div class="md:col-span-8">
                <p class="eyebrow">Katalog &middot; <?php echo e(str_pad((string) $featured->count(), 2, '0', STR_PAD_LEFT)); ?> pilihan</p>
                <h2 class="font-display text-4xl md:text-5xl mt-2 leading-tight">Pilihan dari bengkel</h2>
            </div>
            <div class="md:col-span-4 md:text-right">
                <a href="<?php echo e(route('katalog')); ?>" class="link-arrow text-ink">Semua produk <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'arrow','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow','class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?></a>
            </div>
        </div>
        <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-12">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product,'delay' => ($i + 1) * 100]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product),'delay' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(($i + 1) * 100)]); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                <p class="text-ink-soft">Belum ada produk.</p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </section>

    
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($steps->isNotEmpty()): ?>
    <section class="mt-8 py-16 bg-tint/60 border-y border-rule">
        <div class="max-w-container-max mx-auto px-gutter">
            <div class="grid md:grid-cols-12 gap-6 items-end reveal-on-scroll">
                <div class="md:col-span-7">
                    <p class="eyebrow">Proses pembuatan</p>
                    <h2 class="font-display text-4xl md:text-5xl mt-2 leading-tight">Dari batang bambu sampai <em class="text-amber">siap dimainkan</em></h2>
                </div>
                <p class="md:col-span-5 text-ink-soft">Setiap alat dikerjakan tangan. Bilah dipotong, dikeringkan, lalu nadanya disetel satu per satu sebelum dirangkai.</p>
            </div>
            <ol data-testid="home-steps" class="mt-12 grid grid-cols-2 lg:grid-cols-5 gap-5 lg:items-end">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoopIteration(); ?><?php endif; ?>
                <li class="reveal-on-scroll group" data-delay="<?php echo e($i * 90); ?>">
                    <div class="overflow-hidden rounded-[3px] bg-tint aspect-square lg:aspect-auto <?php echo e($stepHeights[$i] ?? 'lg:h-[220px]'); ?>">
                        <img src="<?php echo e($step->image_url); ?>" alt="<?php echo e($step->title); ?>" loading="lazy" class="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"/>
                    </div>
                    <div class="mt-3 flex items-baseline gap-2.5">
                        <span class="font-mono text-xs text-amber"><?php echo e(str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT)); ?></span>
                        <h3 class="font-semibold text-ink leading-snug"><?php echo e($step->title); ?></h3>
                    </div>
                </li>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
            </ol>
            <a href="<?php echo e(route('profil')); ?>#proses" class="mt-10 link-arrow text-ink">Baca proses lengkap <?php if (isset($component)) { $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.garis-ikon','data' => ['name' => 'arrow','class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('garis-ikon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'arrow','class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $attributes = $__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__attributesOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913)): ?>
<?php $component = $__componentOriginalf8a8fdd9c1ad30ffbddb902981833913; ?>
<?php unset($__componentOriginalf8a8fdd9c1ad30ffbddb902981833913); ?>
<?php endif; ?></a>
        </div>
    </section>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    
    <section class="max-w-container-max mx-auto px-gutter pt-16">
        <div class="relative overflow-hidden bg-band text-on-ink rounded-[3px] px-8 py-12 md:px-14 md:py-14 reveal-on-scroll">
            <div class="grid md:grid-cols-12 gap-8 items-center">
                <div class="md:col-span-8">
                    <p class="font-mono text-[11px] tracking-[0.14em] uppercase opacity-60">Untuk sanggar, sekolah, dan grup kesenian</p>
                    <h2 class="font-display text-4xl md:text-5xl mt-3 leading-tight">Ceritakan alat yang kamu butuhkan.</h2>
                    <p class="mt-4 opacity-75 max-w-xl">Sampaikan jenis alat, jumlah, dan nada. Harga dan lama pengerjaan dikonfirmasi langsung lewat WhatsApp.</p>
                </div>
                <div class="md:col-span-4 flex md:flex-col md:items-end gap-6 items-center justify-between">
                    <div class="bilah" aria-hidden="true"><span></span><span></span><span></span><span></span><span></span><span></span><span></span></div>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($wa): ?>
                    <a href="<?php echo e($wa); ?>" target="_blank" rel="noopener" class="btn border-amber bg-amber text-[#1A1417] hover:-translate-y-0.5 hover:brightness-110">
                        <?php if (isset($component)) { $__componentOriginalca3539e0d920b2ba307b4e983da96e36 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca3539e0d920b2ba307b4e983da96e36 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.wa-icon','data' => ['class' => 'w-4 h-4']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('wa-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-4 h-4']); ?>
<?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::processComponentKey($component); ?>

<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $attributes = $__attributesOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__attributesOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca3539e0d920b2ba307b4e983da96e36)): ?>
<?php $component = $__componentOriginalca3539e0d920b2ba307b4e983da96e36; ?>
<?php unset($__componentOriginalca3539e0d920b2ba307b4e983da96e36); ?>
<?php endif; ?> Chat sekarang
                    </a>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH D:\kuliah\mpi\kelompok baru\kode\mpi-katalog-calung\resources\views/home.blade.php ENDPATH**/ ?>